package edu.bu.met.cs665.DeliverySystem;

/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/22/2024
 * File Name: DeliveryRequest.java
 */

public class DeliveryRequest {

    private Shop shop;
    private String product;

    public DeliveryRequest(Shop shop, String product) {
        this.shop = shop;
        this.product = product;
    }

    @Override
    public String toString() {
        return "DeliveryRequest from shop: " + shop + " for product: " + product;
    }
}
