package edu.bu.met.cs665.DeliverySystem;

/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/22/2024
 * File Name: Driver.java
 */

public class Driver {

    private String name;

    public Driver(String name) {
        this.name = name;
    }


    //when driver receive the request call this method
    public void notify(DeliveryRequest request) {
        System.out.println(name + " received a notification: " + request);
    }

    @Override
    public String toString() {
        return name;
    }
}
