package edu.bu.met.cs665.DeliverySystem;

/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/22/2024
 * File Name: Main.java
 */

public class Main {

    public static void main(String[] args) {


        // create a example shop
        Shop shop = new Shop("Chinese food Store");

        //create 5 drivers
        Driver driver1 = new Driver("Van Driver Allen");
        Driver driver2 = new Driver("Taxi Driver Daniels");
        Driver driver3 = new Driver("Scooter Driver Justin");
        Driver driver4 = new Driver("Van Driver Qinchen");
        Driver driver5 = new Driver("Taxi Driver Mage");

        //add drivers to the list
        shop.addDriver(driver1);
        shop.addDriver(driver2);
        shop.addDriver(driver3);
        shop.addDriver(driver4);
        shop.addDriver(driver5);

        shop.createDeliveryRequest("Noodles");
    }
}
