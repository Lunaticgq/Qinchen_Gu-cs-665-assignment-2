package edu.bu.met.cs665.DeliverySystem;

/**
 * Name: Qinchen Gu
 * Course: CS-665 Software Designs & Patterns
 * Date: 02/22/2024
 * File Name: Shop.java
 */

import java.util.ArrayList;
import java.util.List;

public class Shop {

    private String name;//shop name

    private List<Driver> drivers;

    public Shop(String name) {
        this.name = name;
        drivers = new ArrayList<>();
    }


    //add a driver to the shop
    public void addDriver(Driver driver) {
        drivers.add(driver);
    }


    //The store has requested delivery of a product
    public void createDeliveryRequest(String product) {
        DeliveryRequest request = new DeliveryRequest(this, product);

        //notify all drivers this request
        notifyAllDrivers(request);
    }

    /**  notify all drivers, since it's not a complete program for actual use, in complete program, check will
    be placed to check who accept the request and cancel notification to all other drivers and so on */
    private void notifyAllDrivers(DeliveryRequest request) {
        for (Driver driver : drivers) {
            driver.notify(request);
        }
    }

    @Override
    public String toString() {
        return name;
    }
}
