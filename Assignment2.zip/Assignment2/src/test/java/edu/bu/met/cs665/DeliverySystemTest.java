package edu.bu.met.cs665;

import edu.bu.met.cs665.DeliverySystem.DeliveryRequest;
import edu.bu.met.cs665.DeliverySystem.Driver;
import edu.bu.met.cs665.DeliverySystem.Shop;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class DeliverySystemTest {

    private Shop testShop;
    private ByteArrayOutputStream outContent;

    @Before
    public void setUp() {
        testShop = new Shop("Test Shop");
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void deliveryRequestToStringTest() {
        DeliveryRequest request = new DeliveryRequest(testShop, "Test Product");
        assertEquals("DeliveryRequest from shop: Test Shop for product: Test Product", request.toString());
    }

    @Test
    public void driverToStringAndNotifyTest() {
        Driver driver = new Driver("Test Driver");
        DeliveryRequest request = new DeliveryRequest(testShop, "Test Product");

        // Test driver toString
        assertEquals("Test Driver", driver.toString());

        // Test driver notify
        driver.notify(request);
        assertEquals("Test Driver received a notification: DeliveryRequest from shop: Test Shop for product: Test Product" + System.lineSeparator(), outContent.toString());
        outContent.reset();  // Clearing content for other tests
    }

    @Test
    public void shopTest() {
        Driver testDriver = new Driver("Test Driver");
        testShop.addDriver(testDriver);

        testShop.createDeliveryRequest("Test Product");

        String expectedOutput = "Test Driver received a notification: DeliveryRequest from shop: Test Shop for product: Test Product" + System.lineSeparator();
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    public void broadcastDeliveryRequestToDriversTest() {
        for (int i = 1; i <= 5; i++) {
            //create 5 drivers
            Driver driver = new Driver("Driver " + i);
            testShop.addDriver(driver);
        }

        testShop.createDeliveryRequest("Test Product");

        StringBuilder expectedOutput = new StringBuilder();
        for (int i = 1; i <= 5; i++) {
            expectedOutput.append("Driver ").append(i)
                    .append(" received a notification: DeliveryRequest from shop: Test Shop for product: Test Product")
                    .append(System.lineSeparator());
        }

        assertEquals(expectedOutput.toString(), outContent.toString());
    }
}
